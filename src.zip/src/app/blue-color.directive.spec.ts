import { BlueColorDirective } from './blue-color.directive';

describe('BlueColorDirective', () => {
  it('should create an instance', () => {
    const directive = new BlueColorDirective();
    expect(directive).toBeTruthy();
  });
});
